from distutils.core import setup

setup(
    name          = 'nester',
    version       = '1.0.4',
    py_modules    = ['nester'],
    author        = 'benny',
    author_email  = 'benny08118@gmail.com',
    url           = ' ',
    discription   = 'A simple printer of nested lists'

)